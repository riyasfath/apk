import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/api_service.dart';
import '../routes/app_routes.dart';

class AuthController extends GetxController {
  final ApiService api;
  AuthController(this.api);

  var isLoading = false.obs;
  var error = ''.obs;

  Future<void> tryAutoLogin() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('token');
    if (token != null && token.isNotEmpty) {
      Get.offAllNamed(Routes.home);
    }
  }

  Future<void> login(String username, String password) async {
    isLoading.value = true;
    error.value = '';
    try {
      final token = await api.login(username, password);
      if (token != null && token.isNotEmpty) {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('token', token);
        Get.offAllNamed(Routes.home);
      } else {
        error.value = 'Invalid credentials';
      }
    } catch (e) {
      error.value = 'Login failed';
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('token');
    Get.offAllNamed(Routes.login);
  }
}
