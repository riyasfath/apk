import 'package:get/get.dart';
import '../services/api_service.dart';
import '../controllers/auth_controller.dart';
import '../controllers/product_controller.dart';
import '../views/login_page.dart';
import '../views/home_page.dart';
import '../views/product_detail_page.dart';

class AppPages {
  static final api = ApiService();

  static final List<GetPage> pages = [
    GetPage(
      name: '/login',
      page: () => const LoginPage(),
      binding: BindingsBuilder(() {
        if (!Get.isRegistered<AuthController>()) {
          Get.put(AuthController(api));
        }
      }),
    ),
    GetPage(
      name: '/',
      page: () => const HomePage(),
      binding: BindingsBuilder(() {
        if (!Get.isRegistered<AuthController>()) {
          Get.put(AuthController(api));
        }
        Get.put(ProductController(api));
      }),
    ),
    GetPage(
      name: '/detail',
      page: () => const ProductDetailPage(),
    ),
  ];
}
