abstract class Routes {
  static const login = '/login';
  static const home = '/';
  static const detail = '/detail';
}
