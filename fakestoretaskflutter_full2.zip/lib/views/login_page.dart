import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/auth_controller.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _u = TextEditingController(text: 'johnd');
  final _p = TextEditingController(text: 'm38rmF\$');
  final _form = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    Get.find<AuthController>().tryAutoLogin();
  }

  @override
  Widget build(BuildContext context) {
    final auth = Get.find<AuthController>();
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Card(
                elevation: 2,
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Form(
                    key: _form,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        const FlutterLogo(size: 72),
                        const SizedBox(height: 16),
                        Text('Login', style: Theme.of(context).textTheme.headlineSmall),
                        const SizedBox(height: 12),
                        TextFormField(
                          controller: _u,
                          decoration: const InputDecoration(
                            labelText: 'Username',
                            border: OutlineInputBorder(),
                          ),
                          validator: (v) => (v == null || v.trim().isEmpty) ? 'Enter username' : null,
                        ),
                        const SizedBox(height: 12),
                        TextFormField(
                          controller: _p,
                          obscureText: true,
                          decoration: const InputDecoration(
                            labelText: 'Password',
                            border: OutlineInputBorder(),
                          ),
                          validator: (v) => (v == null || v.isEmpty) ? 'Enter password' : null,
                        ),
                        const SizedBox(height: 12),
                        Obx(() => auth.error.isEmpty
                            ? const SizedBox.shrink()
                            : Text(auth.error.value, style: const TextStyle(color: Colors.red))),
                        const SizedBox(height: 12),
                        Obx(() => FilledButton(
                              onPressed: auth.isLoading.value
                                  ? null
                                  : () {
                                      if (_form.currentState!.validate()) {
                                        auth.login(_u.text, _p.text);
                                      }
                                    },
                              child: auth.isLoading.value
                                  ? const SizedBox(
                                      height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2))
                                  : const Text('Sign in'),
                            )),
                        const SizedBox(height: 8),
                        TextButton(
                          onPressed: () {
                            setState(() {
                              _u.text = 'mor_2314';
                              _p.text = '83r5^_';
                            });
                          },
                          child: const Text('Use alternate demo credentials'),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
